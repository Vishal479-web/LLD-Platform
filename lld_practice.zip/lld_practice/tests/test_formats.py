import json
import unittest

from lld.formats import DesignParseError, DslParser, FormatRegistry, JsonParser


class DslParserTests(unittest.TestCase):
    def test_parses_kinds_heritage_fields_methods(self):
        m = DslParser().parse("interface A\n  run(x: Int): Out\nabstract class B implements A\n  n: List<C>\nclass C extends B, Z\n  - hidden: String\nenum E\n  ONE\n  TWO\n")
        self.assertEqual(m.classes["A"].kind, "interface")
        self.assertEqual(m.classes["B"].implements, ["A"])
        self.assertEqual(m.classes["C"].extends, ["B", "Z"])
        self.assertEqual(m.classes["A"].methods[0].returns, "Out")
        self.assertEqual(m.classes["C"].fields, [("hidden", "String")])
        self.assertEqual(m.classes["E"].fields, [])  # enum constants ignored

    def test_errors_carry_line_numbers(self):
        with self.assertRaises(DesignParseError) as cm:
            DslParser().parse("  orphan: Int\nstruct X\nclass Y\n  ???\n")
        errs = cm.exception.errors
        self.assertTrue(any(e.startswith("line 1") for e in errs))
        self.assertTrue(any(e.startswith("line 2") for e in errs))
        self.assertTrue(any(e.startswith("line 4") for e in errs))

    def test_empty_and_comment_only_rejected(self):
        for text in ("", "   \n", "# just a comment\n"):
            with self.assertRaises(DesignParseError):
                DslParser().parse(text)

    def test_duplicate_class_rejected(self):
        with self.assertRaises(DesignParseError):
            DslParser().parse("class A\nclass A\n")


class JsonParserTests(unittest.TestCase):
    def test_valid(self):
        doc = {"classes": [{"name": "A", "kind": "interface", "methods": [{"name": "go"}]},
                           {"name": "B", "implements": ["A"], "fields": [{"name": "x", "type": "A"}]}]}
        m = JsonParser().parse(json.dumps(doc))
        self.assertEqual(m.implementers_of("A")[0].name, "B")

    def test_bad_inputs(self):
        for bad in ("not json", "{}", '{"classes": []}', '{"classes": [{"kind": "class"}]}',
                    '{"classes": [{"name": "A", "kind": "weird"}]}'):
            with self.assertRaises(DesignParseError, msg=bad):
                JsonParser().parse(bad)


class RegistryTests(unittest.TestCase):
    def test_unknown_format(self):
        with self.assertRaises(ValueError):
            FormatRegistry([DslParser()]).get("uml")

    def test_new_format_plugs_in(self):
        class Tiny(DslParser):
            format_id = "tiny"
        reg = FormatRegistry([DslParser()])
        reg.register(Tiny())
        self.assertEqual(reg.get("tiny").format_id, "tiny")
