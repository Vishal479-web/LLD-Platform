import http.client
import json
import threading
import unittest

from app import serve
from tests.helpers import example, make_service


class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = serve(make_service(), 0)
        cls.port = cls.server.server_address[1]
        threading.Thread(target=cls.server.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()

    def call(self, method, path, body=None, learner="api-user"):
        c = http.client.HTTPConnection("127.0.0.1", self.port)
        c.request(method, path, json.dumps(body) if body is not None else None, {"X-Learner": learner})
        r = c.getresponse()
        return r.status, json.loads(r.read() or b"{}")

    def test_full_flow(self):
        s, d = self.call("GET", "/api/problems")
        self.assertEqual(s, 200); self.assertGreaterEqual(len(d["problems"]), 3)
        s, a = self.call("POST", "/api/attempts", {"problem_id": "parking_lot"})
        self.assertEqual(s, 201)
        self.call("PUT", f"/api/attempts/{a['id']}", {"content": example("parking_lot_good.lld"), "rationale": "r"})
        s, d = self.call("POST", f"/api/attempts/{a['id']}/submit")
        self.assertEqual(s, 202)
        s, d = self.call("GET", f"/api/attempts/{a['id']}")
        self.assertEqual(d["status"], "COMPLETED")
        s, h = self.call("GET", "/api/history?problem_id=parking_lot")
        self.assertEqual(len(h["attempts"]), 1)

    def test_error_codes(self):
        self.assertEqual(self.call("GET", "/api/attempts/missing")[0], 404)
        self.assertEqual(self.call("POST", "/api/attempts", {"problem_id": "zzz"})[0], 404)
        s, a = self.call("POST", "/api/attempts", {"problem_id": "elevator"}, learner="e")
        self.call("PUT", f"/api/attempts/{a['id']}", {"content": "garbage"})
        s, d = self.call("POST", f"/api/attempts/{a['id']}/submit")
        self.assertEqual(s, 422); self.assertTrue(d["details"])
        self.assertEqual(self.call("POST", f"/api/attempts/{a['id']}/retry")[0], 409)
