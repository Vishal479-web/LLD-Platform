import os
from lld.evaluators import EvaluationPipeline, RuleBasedEvaluator
from lld.formats import DslParser, FormatRegistry, JsonParser
from lld.problems import ProblemCatalog
from lld.repository import SqliteAttemptRepository
from lld.service import PracticeService, SynchronousExecutor

EX = os.path.join(os.path.dirname(__file__), "..", "examples")
RATIONALE = ("I put fee calculation behind a strategy so pricing can change without touching the lot, "
             "and gave each floor ownership of its spots because it knows their availability.")


def example(name: str) -> str:
    with open(os.path.join(EX, name)) as f:
        return f.read()


def make_service(optional=None, retries=0, required=None):
    pipeline = EvaluationPipeline(required or [RuleBasedEvaluator()], optional or [],
                                  retries=retries, sleep=lambda s: None)
    return PracticeService(SqliteAttemptRepository(":memory:"), ProblemCatalog(),
                           FormatRegistry([DslParser(), JsonParser()]), pipeline, SynchronousExecutor())


def parse(text):
    return DslParser().parse(text)
