import unittest

from lld.domain import (Attempt, Feedback, Finding, InvalidTransition, Severity, Status,
                        compare_attempts)


def fb(score, *codes):
    return Feedback(score, "", [Finding(c, "x", Severity.ISSUE, c) for c in codes], ["rules"])


class AttemptTests(unittest.TestCase):
    def new(self):
        a = Attempt.start("u", "p", 1)
        a.save_draft("class A", "", "dsl")
        return a

    def test_happy_path(self):
        a = self.new()
        a.submit(); a.start_evaluation(); a.complete(fb(50))
        self.assertEqual(a.status, Status.COMPLETED)

    def test_cannot_submit_empty(self):
        with self.assertRaises(ValueError):
            Attempt.start("u", "p", 1).submit()

    def test_cannot_edit_after_submit(self):
        a = self.new(); a.submit()
        with self.assertRaises(InvalidTransition):
            a.save_draft("class B", "", "dsl")

    def test_cannot_submit_twice_or_complete_early(self):
        a = self.new(); a.submit()
        with self.assertRaises(InvalidTransition):
            a.submit()
        with self.assertRaises(InvalidTransition):
            a.complete(fb(1))

    def test_failed_can_restart_but_completed_cannot(self):
        a = self.new(); a.submit(); a.start_evaluation(); a.fail("boom")
        a.start_evaluation()
        a.complete(fb(1))
        with self.assertRaises(InvalidTransition):
            a.start_evaluation()

    def test_serialisation_roundtrip(self):
        a = self.new(); a.submit(); a.start_evaluation(); a.complete(fb(70, "a"), partial=True)
        b = Attempt.from_dict(a.to_dict())
        self.assertEqual(b.status, Status.PARTIAL)
        self.assertEqual(b.feedback.findings[0].code, "a")

    def test_compare_attempts(self):
        p, c = self.new(), self.new()
        p.feedback, c.feedback = fb(40, "a", "b"), fb(70, "b", "c")
        d = compare_attempts(p, c)
        self.assertEqual(d["score_delta"], 30)
        self.assertEqual((d["resolved"], d["still_open"], d["new"]), (["a"], ["b"], ["c"]))
