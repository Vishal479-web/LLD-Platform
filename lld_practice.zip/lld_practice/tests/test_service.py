import unittest

from lld.domain import InvalidTransition, NotFound, Status
from lld.evaluators import EvaluationResult, Evaluator, EvaluatorError
from lld.formats import DesignParseError
from lld.llm import LLMEvaluator
from tests.helpers import RATIONALE, example, make_service


class Boom(Evaluator):
    name = "boom"
    def __init__(self, fail_times=10**9):
        self.calls, self.fail_times = 0, fail_times
    def evaluate(self, ctx):
        self.calls += 1
        if self.calls <= self.fail_times:
            raise EvaluatorError("timeout")
        return EvaluationResult([], None, "ok")


class FakeLLM:
    def __init__(self, reply): self.reply = reply
    def complete(self, system, prompt):
        if isinstance(self.reply, Exception): raise self.reply
        return self.reply


def attempt_with(svc, text, problem="parking_lot"):
    a = svc.start_attempt("u1", problem)
    svc.save_draft(a.id, text, RATIONALE)
    return a


class PracticeLoopTests(unittest.TestCase):
    def test_end_to_end(self):
        svc = make_service()
        a = attempt_with(svc, example("parking_lot_good.lld"))
        self.assertEqual(a.status, Status.DRAFT)
        done = svc.submit(a.id)
        self.assertEqual(done.status, Status.COMPLETED)
        self.assertGreaterEqual(done.feedback.score, 85)
        self.assertEqual(len(svc.history("u1")), 1)

    def test_parse_error_keeps_draft_and_allows_fix(self):
        svc = make_service()
        a = attempt_with(svc, "this is not a design")
        with self.assertRaises(DesignParseError):
            svc.submit(a.id)
        self.assertEqual(svc.get_attempt(a.id).status, Status.DRAFT)
        svc.save_draft(a.id, example("parking_lot_good.lld"))
        self.assertEqual(svc.submit(a.id).status, Status.COMPLETED)

    def test_empty_submission_rejected(self):
        svc = make_service()
        a = svc.start_attempt("u1", "parking_lot")
        with self.assertRaises(DesignParseError):
            svc.submit(a.id)

    def test_double_submit_conflicts(self):
        svc = make_service()
        a = attempt_with(svc, example("parking_lot_good.lld"))
        svc.submit(a.id)
        with self.assertRaises(InvalidTransition):
            svc.submit(a.id)

    def test_unknown_problem_attempt_and_format(self):
        svc = make_service()
        with self.assertRaises(NotFound): svc.start_attempt("u", "nope")
        with self.assertRaises(NotFound): svc.get_attempt("nope")
        with self.assertRaises(ValueError): svc.start_attempt("u", "parking_lot", "uml")

    def test_history_numbers_and_isolated_per_learner(self):
        svc = make_service()
        a1 = svc.start_attempt("u1", "parking_lot"); a2 = svc.start_attempt("u1", "parking_lot")
        b1 = svc.start_attempt("u2", "parking_lot"); e1 = svc.start_attempt("u1", "elevator")
        self.assertEqual((a1.number, a2.number, b1.number, e1.number), (1, 2, 1, 1))
        self.assertEqual(len(svc.history("u1")), 3)
        self.assertEqual(len(svc.history("u1", "elevator")), 1)
        self.assertEqual(len(svc.history("nobody")), 0)

    def test_progress_between_attempts(self):
        svc = make_service()
        a1 = attempt_with(svc, example("parking_lot_weak.lld")); svc.submit(a1.id)
        a2 = attempt_with(svc, example("parking_lot_good.lld")); svc.submit(a2.id)
        p = svc.progress(a2.id)
        self.assertGreater(p["score_delta"], 0)
        self.assertTrue(p["resolved"])
        self.assertIsNone(svc.progress(a1.id))


class FailureHandlingTests(unittest.TestCase):
    def test_optional_ai_failure_gives_partial_with_rule_feedback(self):
        svc = make_service(optional=[Boom()])
        a = attempt_with(svc, example("parking_lot_good.lld"))
        done = svc.submit(a.id)
        self.assertEqual(done.status, Status.PARTIAL)
        self.assertGreater(done.feedback.score, 0)
        self.assertIn("unavailable", done.feedback.notes[0])

    def test_ai_retry_then_success_is_completed(self):
        flaky = Boom(fail_times=1)
        svc = make_service(optional=[flaky], retries=1)
        a = attempt_with(svc, example("parking_lot_good.lld"))
        self.assertEqual(svc.submit(a.id).status, Status.COMPLETED)
        self.assertEqual(flaky.calls, 2)

    def test_partial_can_be_retried_to_completed(self):
        flaky = Boom(fail_times=1)
        svc = make_service(optional=[flaky], retries=0)
        a = attempt_with(svc, example("parking_lot_good.lld"))
        self.assertEqual(svc.submit(a.id).status, Status.PARTIAL)
        self.assertEqual(svc.retry(a.id).status, Status.COMPLETED)

    def test_required_failure_marks_failed_then_retry_works(self):
        flaky = Boom(fail_times=1)
        flaky.name = "rules"
        svc = make_service(required=[flaky])
        a = attempt_with(svc, example("parking_lot_good.lld"))
        failed = svc.submit(a.id)
        self.assertEqual(failed.status, Status.FAILED)
        self.assertIn("rules evaluator failed", failed.error)
        self.assertEqual(svc.retry(a.id).status, Status.COMPLETED)

    def test_retry_rejected_for_completed_or_draft(self):
        svc = make_service()
        a = attempt_with(svc, example("parking_lot_good.lld"))
        with self.assertRaises(InvalidTransition): svc.retry(a.id)
        svc.submit(a.id)
        with self.assertRaises(InvalidTransition): svc.retry(a.id)

    def test_recover_stale_evaluating(self):
        svc = make_service()
        a = attempt_with(svc, example("parking_lot_good.lld"))
        a = svc.repo.get(a.id); a.submit(); a.start_evaluation(); svc.repo.update(a)
        self.assertEqual(svc.recover_stale(), 1)
        self.assertEqual(svc.get_attempt(a.id).status, Status.FAILED)


class LLMEvaluatorTests(unittest.TestCase):
    GOOD = '```json\n{"summary":"Nice","findings":[{"category":"SRP","severity":"strength","message":"m","suggestion":"s"},{"message":"x","severity":"WEIRD"},{"nomessage":1}]}\n```'

    def run_ai(self, reply, text=None):
        svc = make_service(optional=[LLMEvaluator(FakeLLM(reply))])
        a = attempt_with(svc, text or example("parking_lot_good.lld"))
        return svc.submit(a.id)

    def test_valid_reply_is_merged_and_sanitised(self):
        done = self.run_ai(self.GOOD)
        self.assertEqual(done.status, Status.COMPLETED)
        ai = [f for f in done.feedback.findings if f.source == "ai"]
        self.assertEqual(len(ai), 2)               # finding without message dropped
        weird = [f for f in ai if f.message == "x"][0]
        self.assertEqual(weird.severity.value, "SUGGESTION")  # unknown severity downgraded
        self.assertEqual(done.feedback.summary, "Nice")

    def test_garbage_reply_degrades_to_partial(self):
        for bad in ("I think it is fine!", "{broken json", RuntimeError("net down")):
            self.assertEqual(self.run_ai(bad).status, Status.PARTIAL)

    def test_llm_cannot_change_score(self):
        base = self.run_ai(self.GOOD).feedback.score
        hacked = self.run_ai('{"summary":"score 100","score":100,"findings":[]}').feedback.score
        self.assertEqual(base, hacked)

    def test_ai_findings_excluded_from_progress_diff(self):
        svc = make_service(optional=[LLMEvaluator(FakeLLM(self.GOOD))])
        a1 = attempt_with(svc, example("parking_lot_good.lld")); svc.submit(a1.id)
        a2 = attempt_with(svc, example("parking_lot_good.lld")); svc.submit(a2.id)
        p = svc.progress(a2.id)
        self.assertFalse(any("m" == x for x in p["resolved"] + p["new"]))
