import unittest

from lld.domain import Severity
from lld.evaluators import EvaluationContext, RuleBasedEvaluator
from lld.problems import PARKING_LOT, VENDING
from tests.helpers import RATIONALE, example, parse


def run(text, rationale=RATIONALE, problem=PARKING_LOT):
    ctx = EvaluationContext(problem, parse(text), text, rationale)
    return RuleBasedEvaluator().evaluate(ctx)


def codes(res, sev=None):
    return {f.code for f in res.findings if sev is None or f.severity is sev}


class RuleEvaluatorTests(unittest.TestCase):
    def test_good_design_scores_high_without_issues(self):
        res = run(example("parking_lot_good.lld"))
        self.assertGreaterEqual(res.score, 85)
        self.assertEqual(codes(res, Severity.ISSUE), set())
        self.assertIn("extensibility.ok:Pricing strategy", codes(res))

    def test_weak_design_has_issues_and_low_score(self):
        res = run(example("parking_lot_weak.lld"), rationale="")
        self.assertLess(res.score, 40)
        c = codes(res, Severity.ISSUE)
        self.assertIn("concept.missing:Ticket", c)
        self.assertIn("structure.dangling:Spot", c)
        self.assertIn("behaviour.missing:Calculate the fee", c)
        self.assertIn("rationale.short", codes(res))

    def test_deterministic(self):
        text = example("parking_lot_good.lld")
        a, b = run(text), run(text)
        self.assertEqual((a.score, [f.code for f in a.findings]), (b.score, [f.code for f in b.findings]))

    def test_alternative_valid_naming_is_accepted(self):
        # different names/ownership than the reference design, still recognised
        text = ("interface TariffPolicy\n  charge(t: Receipt): Cash\n"
                "class PerHour implements TariffPolicy\n  charge(t: Receipt): Cash\n"
                "class PerVisit implements TariffPolicy\n  charge(t: Receipt): Cash\n"
                "abstract class Truck\nclass Pickup extends Truck\nclass Lorry extends Truck\n"
                "class Receipt\n  slot: Bay\n  who: Truck\nclass Cash\n  v: Int\n"
                "class Bay\n  free(): boolean\n"
                "class Garage\n  bays: List<Bay>\n  pol: TariffPolicy\n  enter(t: Truck): Receipt\n"
                "  leave(r: Receipt): Cash\n  nearestFreeBay(): Bay\n")
        res = run(text)
        self.assertEqual(codes(res, Severity.ISSUE), set())

    def test_god_class_flagged(self):
        methods = "".join(f"  op{i}()\n" for i in range(10))
        res = run("class ParkingLot\n" + methods + "class Helper\n  x(): Int\n")
        self.assertTrue(any(c.startswith("structure.god:") for c in codes(res)))

    def test_interface_without_implementation_flagged(self):
        res = run("interface PricingStrategy\n  fee(): Int\nclass ParkingLot\n  p: PricingStrategy\n")
        self.assertIn("extensibility.unimplemented:PricingStrategy", codes(res))

    def test_single_implementation_is_partial_credit_suggestion(self):
        res = run("interface PricingStrategy\n  fee(): Int\nclass Hourly implements PricingStrategy\n  fee(): Int\n")
        self.assertIn("extensibility.thin:Pricing strategy", codes(res))

    def test_responsibility_owner_is_suggestion_not_issue(self):
        res = run("class Car\n  calculateFee(): Int\n")
        f = [f for f in res.findings if f.code == "behaviour.owner:Calculate the fee"]
        self.assertEqual(f[0].severity, Severity.SUGGESTION)

    def test_other_problem_uses_its_own_rubric(self):
        res = run("class VendingMachine\n  selectProduct()\n", problem=VENDING)
        self.assertIn("concept.missing:Product", codes(res))
        self.assertNotIn("concept.missing:Ticket", codes(res))

    def test_score_bounds(self):
        self.assertTrue(0 <= run("class X\n").score <= 100)
