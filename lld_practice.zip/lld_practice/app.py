"""Thin HTTP adapter (stdlib). Run: python app.py  ->  http://localhost:8000"""
from __future__ import annotations

import json
import os
import re
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from lld.bootstrap import build_service
from lld.domain import InvalidTransition, NotFound
from lld.formats import DesignParseError
from lld.service import PracticeService

STATIC = os.path.join(os.path.dirname(__file__), "static", "index.html")


def attempt_json(service: PracticeService, a, with_progress=False) -> dict:
    d = a.to_dict()
    if with_progress:
        d["progress"] = service.progress(a.id)
    return d


def make_handler(service: PracticeService):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):  # quiet
            pass

        def _send(self, code: int, payload, ctype="application/json"):
            body = payload if isinstance(payload, bytes) else json.dumps(payload).encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _body(self) -> dict:
            n = int(self.headers.get("Content-Length") or 0)
            if n > 200_000:
                raise ValueError("request too large")
            try:
                return json.loads(self.rfile.read(n) or b"{}")
            except json.JSONDecodeError:
                raise ValueError("body must be valid JSON")

        def _dispatch(self, method: str):
            url = urlparse(self.path)
            q = {k: v[0] for k, v in parse_qs(url.query).items()}
            learner = self.headers.get("X-Learner", "demo")
            path = url.path
            try:
                if method == "GET" and path == "/":
                    return self._send(200, open(STATIC, "rb").read(), "text/html; charset=utf-8")
                if method == "GET" and path == "/api/problems":
                    return self._send(200, {"problems": service.list_problems(), "formats": service.formats.describe()})
                if m := re.fullmatch(r"/api/problems/([\w-]+)", path):
                    return self._send(200, service.get_problem(m[1])) if method == "GET" else self._send(405, {"error": "method not allowed"})
                if method == "POST" and path == "/api/attempts":
                    b = self._body()
                    a = service.start_attempt(learner, b.get("problem_id", ""), b.get("format", "dsl"))
                    return self._send(201, attempt_json(service, a))
                if method == "GET" and path == "/api/history":
                    items = service.history(learner, q.get("problem_id"))
                    return self._send(200, {"attempts": [
                        {"id": a.id, "problem_id": a.problem_id, "number": a.number, "status": a.status.value,
                         "score": a.feedback.score if a.feedback else None, "created_at": a.created_at}
                        for a in items]})
                if m := re.fullmatch(r"/api/attempts/(\w+)", path):
                    if method == "GET":
                        return self._send(200, attempt_json(service, service.get_attempt(m[1]), True))
                    if method == "PUT":
                        b = self._body()
                        a = service.save_draft(m[1], b.get("content", ""), b.get("rationale", ""), b.get("format"))
                        return self._send(200, attempt_json(service, a))
                if m := re.fullmatch(r"/api/attempts/(\w+)/(submit|retry)", path):
                    if method == "POST":
                        fn = service.submit if m[2] == "submit" else service.retry
                        return self._send(202, attempt_json(service, fn(m[1])))
                self._send(404, {"error": "not found"})
            except NotFound as e:
                self._send(404, {"error": str(e)})
            except DesignParseError as e:
                self._send(422, {"error": "design could not be parsed", "details": e.errors})
            except InvalidTransition as e:
                self._send(409, {"error": str(e)})
            except ValueError as e:
                self._send(400, {"error": str(e)})
            except Exception:  # never leak internals
                self._send(500, {"error": "internal error"})

        def do_GET(self): self._dispatch("GET")
        def do_POST(self): self._dispatch("POST")
        def do_PUT(self): self._dispatch("PUT")

    return Handler


def serve(service: PracticeService, port: int = 8000) -> ThreadingHTTPServer:
    return ThreadingHTTPServer(("127.0.0.1", port), make_handler(service))


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "8000"))
    svc = build_service()
    ai = "enabled" if svc.pipeline.optional else "disabled (set ANTHROPIC_API_KEY to enable)"
    print(f"LLD Practice on http://localhost:{port}  | AI review: {ai}")
    serve(svc, port).serve_forever()
