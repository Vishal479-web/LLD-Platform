# AI usage

> **TEMPLATE, edit before submitting.** Replace each entry with what actually happened in *your* sessions
> and your own judgement. The entries below describe the decisions as this prototype was built with Claude; keep only what is true for you.

1. **Submission format.** *AI suggested:* accept UML images and let an LLM read them. *Decision:* rejected for the MVP; used a text DSL (plus JSON) parsed deterministically. *Why:* image reading is unreliable, can't be unit-tested, and the DSL still captures classes, relationships and responsibilities. The parser interface leaves room for diagram formats later.
2. **Who scores.** *AI suggested:* let the LLM grade 0-100. *Decision:* rejected. Rules own the score; the LLM only adds commentary, validated and capped. *Why:* reproducible scores, attempt diffs, and the submission cannot steer the grade (covered by `test_llm_cannot_change_score`).
3. **Multiple valid designs.** *AI suggested:* compare against one reference class diagram. *Decision:* replaced with a rubric of concepts/behaviours + aliases, with subjective points phrased as trade-off questions. *Why:* avoids punishing valid alternatives (`test_alternative_valid_naming_is_accepted`).
4. **Failure modes.** *AI suggested:* a job queue with retries. *Decision:* kept an in-process pool, but modelled PARTIAL/FAILED states and `recover_stale()`. *Why:* the assignment says not to build distributed systems; the states give the same learner-visible behaviour.
5. **Tests.** *AI generated* the first test batch; I changed/kept the ones targeting failure paths (garbage LLM output, double submit, crash recovery) and fixed one ordering assumption that the AI test got wrong (findings are sorted by severity).
