"""Application service: orchestrates the practice loop. No HTTP, no SQL, no LLM details here."""
from __future__ import annotations

import threading
from concurrent.futures import Executor, ThreadPoolExecutor
from typing import Optional

from .domain import (RETRYABLE, Attempt, InvalidTransition, NotFound, Status, compare_attempts)
from .evaluators import EvaluationContext, EvaluationFailed, EvaluationPipeline
from .formats import FormatRegistry
from .problems import ProblemCatalog
from .repository import AttemptRepository


class SynchronousExecutor(Executor):
    """Runs work inline; used in tests and handy for debugging."""
    def submit(self, fn, *args, **kwargs):
        from concurrent.futures import Future
        f: Future = Future()
        try:
            f.set_result(fn(*args, **kwargs))
        except Exception as e:  # pragma: no cover
            f.set_exception(e)
        return f


class PracticeService:
    def __init__(self, repo: AttemptRepository, catalog: ProblemCatalog, formats: FormatRegistry,
                 pipeline: EvaluationPipeline, executor: Executor | None = None):
        self.repo, self.catalog, self.formats, self.pipeline = repo, catalog, formats, pipeline
        self.executor = executor or ThreadPoolExecutor(max_workers=2)
        self._lock = threading.Lock()  # guards the check-then-transition on submit/retry

    # -- catalogue --------------------------------------------------------
    def list_problems(self):
        return [p.summary() for p in self.catalog.list()]

    def get_problem(self, problem_id: str):
        return self.catalog.get(problem_id).detail()

    # -- practice loop ----------------------------------------------------
    def start_attempt(self, learner_id: str, problem_id: str, fmt: str = "dsl") -> Attempt:
        self.catalog.get(problem_id)
        self.formats.get(fmt)
        attempt = Attempt.start(learner_id, problem_id, self.repo.next_number(learner_id, problem_id), fmt)
        self.repo.add(attempt)
        return attempt

    def save_draft(self, attempt_id: str, content: str, rationale: str = "", fmt: Optional[str] = None) -> Attempt:
        attempt = self.repo.get(attempt_id)
        fmt = fmt or attempt.format
        self.formats.get(fmt)
        attempt.save_draft(content, rationale, fmt)
        self.repo.update(attempt)
        return attempt

    def submit(self, attempt_id: str) -> Attempt:
        """Validates the design synchronously (fast feedback on syntax), then evaluates in background.
        A parse error leaves the attempt as a DRAFT so the learner can fix and resubmit."""
        with self._lock:
            attempt = self.repo.get(attempt_id)
            self.formats.get(attempt.format).parse(attempt.content)  # raises DesignParseError
            attempt.submit()
            self.repo.update(attempt)
        self.executor.submit(self._evaluate, attempt.id)
        return self.repo.get(attempt.id)

    def retry(self, attempt_id: str) -> Attempt:
        with self._lock:
            attempt = self.repo.get(attempt_id)
            if attempt.status not in RETRYABLE:
                raise InvalidTransition(f"attempt is {attempt.status.value}; only FAILED/PARTIAL can be retried")
        self.executor.submit(self._evaluate, attempt_id)
        return self.repo.get(attempt_id)

    def get_attempt(self, attempt_id: str) -> Attempt:
        return self.repo.get(attempt_id)

    def history(self, learner_id: str, problem_id: Optional[str] = None) -> list[Attempt]:
        return self.repo.list_for(learner_id, problem_id)

    def progress(self, attempt_id: str) -> Optional[dict]:
        """Diff versus the learner's previous evaluated attempt on the same problem."""
        current = self.repo.get(attempt_id)
        if not current.feedback:
            return None
        earlier = [a for a in self.repo.list_for(current.learner_id, current.problem_id)
                   if a.number < current.number and a.feedback]
        if not earlier:
            return None
        return compare_attempts(max(earlier, key=lambda a: a.number), current)

    def recover_stale(self) -> int:
        """Call at startup: attempts left EVALUATING by a crash become FAILED (retryable)."""
        stale = self.repo.find_by_status(Status.EVALUATING)
        for a in stale:
            a.fail("evaluation was interrupted (server restart); please retry")
            self.repo.update(a)
        return len(stale)

    # -- background work --------------------------------------------------
    def _evaluate(self, attempt_id: str) -> None:
        try:
            attempt = self.repo.get(attempt_id)
            attempt.start_evaluation()
            self.repo.update(attempt)
        except (InvalidTransition, NotFound):
            return  # someone else got there first, or it vanished
        try:
            problem = self.catalog.get(attempt.problem_id)
            model = self.formats.get(attempt.format).parse(attempt.content)
            ctx = EvaluationContext(problem, model, attempt.content, attempt.rationale)
            feedback, partial = self.pipeline.run(ctx)
            attempt.complete(feedback, partial)
        except EvaluationFailed as e:
            attempt.fail(str(e))
        except Exception as e:  # last line of defence so an attempt is never stuck EVALUATING
            attempt.fail(f"unexpected error: {e.__class__.__name__}: {e}")
        self.repo.update(attempt)
