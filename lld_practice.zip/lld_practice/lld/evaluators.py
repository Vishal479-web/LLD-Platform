"""Evaluation: a small Evaluator interface, a deterministic rubric evaluator, and a pipeline
that tolerates failure of optional (AI) evaluators."""
from __future__ import annotations

import re
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, replace
from typing import Callable, Optional

from .domain import SEVERITY_ORDER, Feedback, Finding, Severity
from .model import ClassSpec, DesignModel
from .problems import Problem


class EvaluatorError(Exception):
    """An evaluator could not produce a result (timeout, bad output...). Safe to retry."""


class EvaluationFailed(Exception):
    """A *required* evaluator failed, so there is no usable feedback."""


@dataclass
class EvaluationContext:
    problem: Problem
    model: DesignModel
    raw_design: str = ""
    rationale: str = ""
    prior_findings: list[Finding] = field(default_factory=list)


@dataclass
class EvaluationResult:
    findings: list[Finding] = field(default_factory=list)
    score: Optional[int] = None       # only deterministic evaluators set a score
    summary: Optional[str] = None


class Evaluator(ABC):
    name: str

    @abstractmethod
    def evaluate(self, ctx: EvaluationContext) -> EvaluationResult: ...


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]", "", s.lower())


def _matches(name: str, fragments) -> bool:
    n = _norm(name)
    return any(_norm(f) in n for f in fragments)


class RuleBasedEvaluator(Evaluator):
    """Deterministic, explainable checks. Phrases subjective points as trade-offs, not errors,
    because many valid designs exist. The 0-100 score comes only from here."""
    name = "rules"

    W_CONCEPTS, W_BEHAVIOURS, W_STRUCTURE, W_EXTENSIBILITY = 30, 30, 20, 20

    def evaluate(self, ctx: EvaluationContext) -> EvaluationResult:
        findings: list[Finding] = []
        c_ratio = self._concepts(ctx, findings)
        b_ratio = self._behaviours(ctx, findings)
        structure = self._structure(ctx, findings)
        ext = self._extensibility(ctx, findings)
        self._rationale(ctx, findings)
        score = round(c_ratio * self.W_CONCEPTS + b_ratio * self.W_BEHAVIOURS
                      + structure * self.W_STRUCTURE + ext * self.W_EXTENSIBILITY)
        score = max(0, min(100, score))
        return EvaluationResult(findings, score, self._summary(score, findings))

    # -- checks -----------------------------------------------------------
    def _concepts(self, ctx, out) -> float:
        concepts = ctx.problem.rubric.concepts
        hit = 0
        for c in concepts:
            found = next((k for k in ctx.model.classes.values() if _matches(k.name, c.aliases)), None)
            if found:
                hit += 1
            else:
                out.append(Finding(f"concept.missing:{c.name}", "Domain model", Severity.ISSUE,
                                   f"No class models '{c.name}'.",
                                   f"Think about {c.why}. Name it whatever you like (e.g. {c.aliases[0]})."))
        if hit == len(concepts):
            out.append(Finding("concept.all", "Domain model", Severity.STRENGTH,
                               "All the core domain concepts are modelled as classes."))
        return hit / len(concepts)

    def _behaviours(self, ctx, out) -> float:
        behaviours = ctx.problem.rubric.behaviours
        covered = 0
        for b in behaviours:
            owners = [k for k in ctx.model.classes.values()
                      if any(_matches(m.name, b.keywords) for m in k.methods)]
            if not owners:
                out.append(Finding(f"behaviour.missing:{b.name}", "Behaviour", Severity.ISSUE,
                                   f"No method appears to implement '{b.name}'.",
                                   "Add a method for it and decide which class owns that responsibility."))
                continue
            covered += 1
            if b.preferred_owners and not any(_matches(o.name, b.preferred_owners) for o in owners):
                names = ", ".join(o.name for o in owners)
                out.append(Finding(f"behaviour.owner:{b.name}", "Responsibilities", Severity.SUGGESTION,
                                   f"'{b.name}' lives on {names}. Is that the class with the data it needs?",
                                   f"Designs often place this on something like: {', '.join(b.preferred_owners[:3])}. "
                                   "Keep yours if you can justify it in the rationale."))
        return covered / len(behaviours)

    def _structure(self, ctx, out) -> float:
        score, model = 1.0, ctx.model
        concrete = [c for c in model.classes.values() if c.kind == "class"]
        total_methods = sum(len(c.methods) for c in model.classes.values())
        for c in model.classes.values():
            if len(c.methods) >= 8 and total_methods and len(c.methods) / total_methods > 0.5:
                score -= 0.35
                out.append(Finding(f"structure.god:{c.name}", "Responsibilities", Severity.SUGGESTION,
                                   f"{c.name} holds {len(c.methods)} of {total_methods} methods.",
                                   "Which of these could move to a collaborator that owns the related data?"))
        anemic = [c.name for c in concrete if len(c.fields) >= 2 and not c.methods]
        if len(concrete) >= 3 and len(anemic) / len(concrete) > 0.5:
            score -= 0.2
            out.append(Finding("structure.anemic", "Responsibilities", Severity.SUGGESTION,
                               f"Most classes only hold data ({', '.join(anemic)}).",
                               "Data holders are fine sometimes (e.g. Ticket), but ask whether behaviour "
                               "that uses a class's fields could live on that class."))
        dangling = sorted(model.dangling_references())
        for ref in dangling:
            out.append(Finding(f"structure.dangling:{ref}", "Consistency", Severity.ISSUE,
                               f"'{ref}' is used in a type or parent but never declared.",
                               "Declare it, or replace it with a type you already modelled."))
        score -= min(0.4, 0.15 * len(dangling))
        if len(model.classes) >= 3:
            isolated = sorted(set(model.classes) - model.related_names())
            for name in isolated:
                out.append(Finding(f"structure.isolated:{name}", "Relationships", Severity.SUGGESTION,
                                   f"{name} has no relationship to any other class.",
                                   "How does it collaborate? Add a field, parameter or inheritance link."))
            score -= min(0.3, 0.1 * len(isolated))
        if not dangling and score >= 0.99:
            out.append(Finding("structure.clean", "Responsibilities", Severity.STRENGTH,
                               "Responsibilities look reasonably spread and references are consistent."))
        return max(0.0, score)

    def _extensibility(self, ctx, out) -> float:
        patterns, model = ctx.problem.rubric.patterns, ctx.model
        total, earned = len(patterns), 0.0
        for p in patterns:
            abstractions = [c for c in model.classes.values()
                            if c.is_abstraction and _matches(c.name, p.aliases)]
            if not abstractions:
                out.append(Finding(f"extensibility.missing:{p.name}", "Extensibility", Severity.SUGGESTION,
                                   f"No abstraction for '{p.name}' found.",
                                   f"Requirement: \"{p.requirement}\". An interface/abstract class here {p.why}. "
                                   "If you chose conditionals instead, explain the trade-off in your rationale."))
                continue
            best = max(abstractions, key=lambda a: len(model.implementers_of(a.name)))
            n = len(model.implementers_of(best.name))
            if n >= 2:
                earned += 1
                out.append(Finding(f"extensibility.ok:{p.name}", "Extensibility", Severity.STRENGTH,
                                   f"{best.name} has {n} implementations: {p.name} is in place."))
            else:
                earned += 0.5
                out.append(Finding(f"extensibility.thin:{p.name}", "Extensibility", Severity.SUGGESTION,
                                   f"{best.name} has {n} implementation(s).",
                                   "A second implementation shows whether the abstraction is right."))
        for c in model.classes.values():
            if c.kind == "interface" and not model.implementers_of(c.name):
                earned -= 0.3
                out.append(Finding(f"extensibility.unimplemented:{c.name}", "Extensibility", Severity.SUGGESTION,
                                   f"Interface {c.name} has no implementations.",
                                   "Add an implementation or remove the interface."))
        return 1.0 if total == 0 else max(0.0, min(1.0, earned / total))

    def _rationale(self, ctx, out) -> None:
        if len(ctx.rationale.split()) < 15:
            out.append(Finding("rationale.short", "Reasoning", Severity.SUGGESTION,
                               "The rationale is very short.",
                               "Explain 1-2 trade-offs you made (why this owner? why this abstraction?)."))

    @staticmethod
    def _summary(score: int, findings: list[Finding]) -> str:
        issues = sum(1 for f in findings if f.severity is Severity.ISSUE)
        sugg = sum(1 for f in findings if f.severity is Severity.SUGGESTION)
        band = ("Strong design" if score >= 85 else "Solid start" if score >= 65
                else "Needs another pass" if score >= 40 else "Major gaps")
        return f"{band}: {issues} issue(s) to fix and {sugg} trade-off(s) to consider."


class EvaluationPipeline:
    """Runs required evaluators (failure => FAILED) then optional ones (failure => PARTIAL)."""

    def __init__(self, required: list[Evaluator], optional: list[Evaluator] | None = None,
                 retries: int = 1, backoff: float = 0.5,
                 sleep: Callable[[float], None] = time.sleep):
        if not required:
            raise ValueError("at least one required evaluator is needed")
        self.required, self.optional = required, optional or []
        self.retries, self.backoff, self._sleep = retries, backoff, sleep

    def run(self, ctx: EvaluationContext) -> tuple[Feedback, bool]:
        findings: list[Finding] = []
        score, summary, notes, sources = None, None, [], []
        partial = False
        for ev in self.required:
            try:
                res = ev.evaluate(replace(ctx, prior_findings=list(findings)))
            except Exception as e:  # a required evaluator must never leak a stack trace
                raise EvaluationFailed(f"{ev.name} evaluator failed: {e}") from e
            findings += res.findings
            score = res.score if res.score is not None else score
            summary = res.summary or summary
            sources.append(ev.name)
        for ev in self.optional:
            res = self._try(ev, replace(ctx, prior_findings=list(findings)), notes)
            if res is None:
                partial = True
                continue
            findings += res.findings
            summary = res.summary or summary
            sources.append(ev.name)
        findings.sort(key=lambda f: SEVERITY_ORDER[f.severity])
        return Feedback(score or 0, summary or "", findings, sources, notes), partial

    def _try(self, ev: Evaluator, ctx: EvaluationContext, notes: list[str]):
        last = ""
        for i in range(self.retries + 1):
            try:
                return ev.evaluate(ctx)
            except Exception as e:
                last = str(e) or e.__class__.__name__
                if i < self.retries:
                    self._sleep(self.backoff * (2 ** i))
        notes.append(f"'{ev.name}' review unavailable ({last}). Rule-based feedback is shown; retry later.")
        return None
