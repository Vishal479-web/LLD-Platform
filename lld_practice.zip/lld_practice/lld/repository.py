"""Persistence port + SQLite adapter. Swap for Postgres by implementing AttemptRepository."""
from __future__ import annotations

import json
import sqlite3
import threading
from abc import ABC, abstractmethod
from typing import Optional

from .domain import Attempt, NotFound, Status


class AttemptRepository(ABC):
    @abstractmethod
    def add(self, attempt: Attempt) -> None: ...
    @abstractmethod
    def update(self, attempt: Attempt) -> None: ...
    @abstractmethod
    def get(self, attempt_id: str) -> Attempt: ...
    @abstractmethod
    def list_for(self, learner_id: str, problem_id: Optional[str] = None) -> list[Attempt]: ...
    @abstractmethod
    def next_number(self, learner_id: str, problem_id: str) -> int: ...
    @abstractmethod
    def find_by_status(self, status: Status) -> list[Attempt]: ...


class SqliteAttemptRepository(AttemptRepository):
    def __init__(self, path: str = "lld_practice.db"):
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._lock = threading.RLock()
        with self._lock:
            self._conn.execute("""CREATE TABLE IF NOT EXISTS attempts (
                id TEXT PRIMARY KEY, learner_id TEXT, problem_id TEXT, number INTEGER,
                status TEXT, created_at TEXT, data TEXT NOT NULL)""")
            self._conn.execute("CREATE INDEX IF NOT EXISTS ix_l_p ON attempts(learner_id, problem_id)")
            self._conn.commit()

    def add(self, a: Attempt) -> None:
        with self._lock:
            self._conn.execute("INSERT INTO attempts VALUES (?,?,?,?,?,?,?)",
                               (a.id, a.learner_id, a.problem_id, a.number, a.status.value,
                                a.created_at, json.dumps(a.to_dict())))
            self._conn.commit()

    def update(self, a: Attempt) -> None:
        with self._lock:
            cur = self._conn.execute("UPDATE attempts SET status=?, data=? WHERE id=?",
                                     (a.status.value, json.dumps(a.to_dict()), a.id))
            self._conn.commit()
            if cur.rowcount == 0:
                raise NotFound(f"attempt '{a.id}' not found")

    def get(self, attempt_id: str) -> Attempt:
        with self._lock:
            row = self._conn.execute("SELECT data FROM attempts WHERE id=?", (attempt_id,)).fetchone()
        if not row:
            raise NotFound(f"attempt '{attempt_id}' not found")
        return Attempt.from_dict(json.loads(row[0]))

    def list_for(self, learner_id, problem_id=None) -> list[Attempt]:
        sql, args = "SELECT data FROM attempts WHERE learner_id=?", [learner_id]
        if problem_id:
            sql, args = sql + " AND problem_id=?", args + [problem_id]
        with self._lock:
            rows = self._conn.execute(sql + " ORDER BY created_at DESC, number DESC", args).fetchall()
        return [Attempt.from_dict(json.loads(r[0])) for r in rows]

    def next_number(self, learner_id, problem_id) -> int:
        with self._lock:
            n = self._conn.execute("SELECT COALESCE(MAX(number),0) FROM attempts WHERE learner_id=? AND problem_id=?",
                                   (learner_id, problem_id)).fetchone()[0]
        return n + 1

    def find_by_status(self, status: Status) -> list[Attempt]:
        with self._lock:
            rows = self._conn.execute("SELECT data FROM attempts WHERE status=?", (status.value,)).fetchall()
        return [Attempt.from_dict(json.loads(r[0])) for r in rows]
