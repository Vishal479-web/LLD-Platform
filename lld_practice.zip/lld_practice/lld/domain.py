"""Core domain objects: Attempt (with a guarded state machine), Finding, Feedback."""
from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional


def utcnow() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


class NotFound(Exception):
    pass


class InvalidTransition(Exception):
    pass


class Status(str, Enum):
    DRAFT = "DRAFT"
    SUBMITTED = "SUBMITTED"
    EVALUATING = "EVALUATING"
    COMPLETED = "COMPLETED"   # all evaluators succeeded
    PARTIAL = "PARTIAL"       # rule feedback available, optional (AI) review failed
    FAILED = "FAILED"         # no usable feedback; retryable


class Severity(str, Enum):
    ISSUE = "ISSUE"            # objectively wrong / missing
    SUGGESTION = "SUGGESTION"  # a trade-off worth thinking about
    STRENGTH = "STRENGTH"      # something done well


SEVERITY_ORDER = {Severity.ISSUE: 0, Severity.SUGGESTION: 1, Severity.STRENGTH: 2}


@dataclass(frozen=True)
class Finding:
    """One piece of feedback. `code` is stable for rule findings so attempts can be diffed."""
    code: str
    category: str
    severity: Severity
    message: str
    suggestion: str = ""
    source: str = "rules"

    def to_dict(self) -> dict:
        return {"code": self.code, "category": self.category, "severity": self.severity.value,
                "message": self.message, "suggestion": self.suggestion, "source": self.source}

    @staticmethod
    def from_dict(d: dict) -> "Finding":
        return Finding(d["code"], d["category"], Severity(d["severity"]), d["message"],
                       d.get("suggestion", ""), d.get("source", "rules"))


@dataclass
class Feedback:
    score: int
    summary: str
    findings: list[Finding]
    sources: list[str]
    notes: list[str] = field(default_factory=list)  # e.g. "AI review unavailable: timeout"

    def to_dict(self) -> dict:
        return {"score": self.score, "summary": self.summary, "sources": self.sources,
                "notes": self.notes, "findings": [f.to_dict() for f in self.findings]}

    @staticmethod
    def from_dict(d: dict) -> "Feedback":
        return Feedback(d["score"], d["summary"], [Finding.from_dict(f) for f in d["findings"]],
                        d["sources"], d.get("notes", []))


_ALLOWED = {
    Status.DRAFT: {Status.SUBMITTED},
    Status.SUBMITTED: {Status.EVALUATING},
    Status.EVALUATING: {Status.COMPLETED, Status.PARTIAL, Status.FAILED},
    Status.FAILED: {Status.EVALUATING},
    Status.PARTIAL: {Status.EVALUATING},
    Status.COMPLETED: set(),
}
RETRYABLE = {Status.FAILED, Status.PARTIAL}


@dataclass
class Attempt:
    id: str
    learner_id: str
    problem_id: str
    number: int                      # nth attempt by this learner on this problem
    format: str = "dsl"
    content: str = ""
    rationale: str = ""
    status: Status = Status.DRAFT
    feedback: Optional[Feedback] = None
    error: Optional[str] = None
    created_at: str = field(default_factory=utcnow)
    submitted_at: Optional[str] = None
    evaluated_at: Optional[str] = None

    @staticmethod
    def start(learner_id: str, problem_id: str, number: int, fmt: str = "dsl") -> "Attempt":
        return Attempt(uuid.uuid4().hex[:12], learner_id, problem_id, number, format=fmt)

    # --- behaviour -------------------------------------------------------
    def _go(self, new: Status) -> None:
        if new not in _ALLOWED[self.status]:
            raise InvalidTransition(f"cannot move attempt from {self.status.value} to {new.value}")
        self.status = new

    def save_draft(self, content: str, rationale: str, fmt: str) -> None:
        if self.status is not Status.DRAFT:
            raise InvalidTransition("only drafts can be edited; start a new attempt instead")
        self.content, self.rationale, self.format = content, rationale, fmt

    def submit(self) -> None:
        if not self.content.strip():
            raise ValueError("cannot submit an empty design")
        self._go(Status.SUBMITTED)
        self.submitted_at = utcnow()

    def start_evaluation(self) -> None:
        self._go(Status.EVALUATING)
        self.error = None

    def complete(self, feedback: Feedback, partial: bool = False) -> None:
        self._go(Status.PARTIAL if partial else Status.COMPLETED)
        self.feedback, self.evaluated_at = feedback, utcnow()

    def fail(self, error: str) -> None:
        self._go(Status.FAILED)
        self.error, self.evaluated_at = error, utcnow()

    # --- (de)serialisation ----------------------------------------------
    def to_dict(self) -> dict:
        return {"id": self.id, "learner_id": self.learner_id, "problem_id": self.problem_id,
                "number": self.number, "format": self.format, "content": self.content,
                "rationale": self.rationale, "status": self.status.value,
                "feedback": self.feedback.to_dict() if self.feedback else None,
                "error": self.error, "created_at": self.created_at,
                "submitted_at": self.submitted_at, "evaluated_at": self.evaluated_at}

    @staticmethod
    def from_dict(d: dict) -> "Attempt":
        d = dict(d)
        d["status"] = Status(d["status"])
        d["feedback"] = Feedback.from_dict(d["feedback"]) if d.get("feedback") else None
        return Attempt(**d)


def compare_attempts(previous: Attempt, current: Attempt) -> dict:
    """Progress between two attempts, using stable rule-finding codes only."""
    def open_codes(a: Attempt) -> dict[str, Finding]:
        if not a.feedback:
            return {}
        return {f.code: f for f in a.feedback.findings
                if f.source == "rules" and f.severity is not Severity.STRENGTH}
    before, after = open_codes(previous), open_codes(current)
    return {
        "previous_number": previous.number,
        "score_delta": (current.feedback.score - previous.feedback.score)
        if previous.feedback and current.feedback else None,
        "resolved": [before[c].message for c in before if c not in after],
        "still_open": [after[c].message for c in after if c in before],
        "new": [after[c].message for c in after if c not in before],
    }
