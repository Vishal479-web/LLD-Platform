"""Problem catalogue. Each problem carries a Rubric describing *what a good design must cover*
without prescribing one answer (aliases allow many valid namings/structures)."""
from __future__ import annotations

from dataclasses import dataclass, field

from .domain import NotFound


@dataclass(frozen=True)
class Concept:
    name: str
    aliases: tuple[str, ...]
    why: str


@dataclass(frozen=True)
class Behaviour:
    name: str
    keywords: tuple[str, ...]            # substrings of a method name
    preferred_owners: tuple[str, ...] = ()  # class-name fragments that usually own it (soft)
    why: str = ""


@dataclass(frozen=True)
class PatternHint:
    name: str
    aliases: tuple[str, ...]             # fragments of an interface/abstract class name
    why: str
    requirement: str                      # which requirement makes this variation point real


@dataclass(frozen=True)
class Rubric:
    concepts: tuple[Concept, ...]
    behaviours: tuple[Behaviour, ...]
    patterns: tuple[PatternHint, ...] = ()


@dataclass(frozen=True)
class Problem:
    id: str
    title: str
    difficulty: str
    statement: str
    requirements: tuple[str, ...]
    hints: tuple[str, ...]
    rubric: Rubric

    def summary(self) -> dict:
        return {"id": self.id, "title": self.title, "difficulty": self.difficulty,
                "statement": self.statement}

    def detail(self) -> dict:
        return {**self.summary(), "requirements": list(self.requirements), "hints": list(self.hints)}


PARKING_LOT = Problem(
    "parking_lot", "Parking Lot", "Easy",
    "Design a multi-floor parking lot that parks and releases vehicles and charges for the time parked.",
    ("Multiple floors, each with spots of different sizes (bike, car, truck).",
     "Entry issues a ticket; exit takes the ticket and returns the fee.",
     "A vehicle is assigned the nearest free spot that fits it.",
     "Pricing differs by vehicle type and may change later (hourly, flat, weekend rates)."),
    ("Who knows which spots are free: the lot, the floor, or the spot?",
     "What changes when the pricing rules change? Can you avoid touching ParkingLot?"),
    Rubric(
        concepts=(
            Concept("Parking lot", ("parkinglot", "lot", "garage"), "an entry point that coordinates the flow"),
            Concept("Parking spot", ("spot", "slot", "space", "bay"), "spots carry type and availability"),
            Concept("Vehicle", ("vehicle", "car", "bike", "truck"), "different vehicle types drive spot fit and price"),
            Concept("Ticket", ("ticket", "receipt"), "links a vehicle, a spot and entry time so exit can price it"),
            Concept("Pricing", ("pricing", "fee", "rate", "tariff", "charge"), "pricing rules are a separate responsibility"),
        ),
        behaviours=(
            Behaviour("Park a vehicle", ("park", "enter", "checkin", "admit"), ("lot", "garage", "manager")),
            Behaviour("Release a vehicle", ("unpark", "exit", "leave", "checkout", "release", "remove"), ("lot", "garage", "manager")),
            Behaviour("Calculate the fee", ("fee", "price", "charge", "cost", "calculate"), ("pricing", "fee", "rate", "ticket", "lot", "strategy", "policy")),
            Behaviour("Find an available spot", ("find", "available", "allocate", "assign", "nearest", "free"), ("floor", "lot", "spot", "allocator", "strategy")),
        ),
        patterns=(
            PatternHint("Pricing strategy", ("pricing", "fee", "rate", "tariff", "strategy", "policy"),
                        "lets pricing rules vary without editing the lot", "Pricing differs by vehicle type and may change later"),
            PatternHint("Vehicle polymorphism", ("vehicle",),
                        "vehicle types share behaviour behind one abstraction", "Spots of different sizes for bikes, cars and trucks"),
        ),
    ),
)

ELEVATOR = Problem(
    "elevator", "Elevator System", "Medium",
    "Design the control logic for a building with several elevators serving many floors.",
    ("N elevators, M floors; passengers press up/down on a floor and a destination inside the car.",
     "Each elevator moves, stops, opens and closes doors, and tracks direction.",
     "A dispatcher assigns each request to an elevator.",
     "The assignment algorithm may be swapped later (nearest car, least loaded, zoning)."),
    ("Is an elevator's behaviour different when idle, moving up, or moving down?",
     "Who decides which elevator answers a hall call?"),
    Rubric(
        concepts=(
            Concept("Elevator", ("elevator", "lift", "car"), "owns position, direction and its stop queue"),
            Concept("Controller / dispatcher", ("controller", "dispatcher", "scheduler", "system", "manager"), "coordinates elevators"),
            Concept("Request", ("request", "call", "stop"), "a first-class request decouples input from handling"),
            Concept("Direction / state", ("direction", "state", "status"), "movement state must be modelled explicitly"),
            Concept("Door", ("door",), "door behaviour has rules (not while moving)"),
        ),
        behaviours=(
            Behaviour("Accept a request", ("request", "call", "press", "submit"), ("controller", "dispatcher", "system", "button", "panel")),
            Behaviour("Assign an elevator", ("assign", "dispatch", "schedule", "select", "choose"), ("controller", "dispatcher", "scheduler", "strategy", "system")),
            Behaviour("Move", ("move", "step", "goto", "run", "tick", "advance"), ("elevator", "car", "lift")),
            Behaviour("Open / close doors", ("open", "close"), ("door", "elevator", "car")),
        ),
        patterns=(
            PatternHint("Dispatch strategy", ("strategy", "scheduler", "dispatch", "algorithm", "policy"),
                        "swap assignment algorithms without touching the controller", "The assignment algorithm may be swapped later"),
            PatternHint("State pattern", ("state",),
                        "idle / moving-up / moving-down behave differently", "Each elevator tracks direction and stops"),
        ),
    ),
)

VENDING = Problem(
    "vending_machine", "Vending Machine", "Easy",
    "Design a vending machine that sells products, accepts payment and returns change.",
    ("Slots hold products with price and quantity.",
     "A user selects a product, pays (coins or notes), receives the product and change.",
     "The machine can refund when the user cancels and can be restocked by an operator.",
     "Operations are only valid in certain situations (e.g. cannot dispense before payment)."),
    ("What happens if the user presses 'dispense' before paying? Where is that rule written?",
     "How would you add card payments later?"),
    Rubric(
        concepts=(
            Concept("Vending machine", ("vendingmachine", "machine"), "the coordinating entry point"),
            Concept("Product", ("product", "item", "snack"), "what is sold"),
            Concept("Inventory / slot", ("inventory", "stock", "slot", "rack", "shelf"), "quantity tracking is its own responsibility"),
            Concept("Payment / money", ("payment", "coin", "cash", "money", "note", "wallet"), "money handling is modelled, not just an int"),
            Concept("State", ("state",), "valid operations depend on the machine's state"),
        ),
        behaviours=(
            Behaviour("Select a product", ("select", "choose", "pick"), ("machine", "state")),
            Behaviour("Accept money", ("insert", "pay", "deposit", "accept", "addmoney", "addcoin"), ("machine", "state", "payment", "wallet")),
            Behaviour("Dispense", ("dispense", "deliver", "release"), ("machine", "state", "inventory", "slot")),
            Behaviour("Refund / change", ("refund", "change", "cancel", "return"), ("machine", "state", "payment", "wallet")),
            Behaviour("Restock", ("restock", "refill", "add", "load"), ("inventory", "stock", "machine", "slot")),
        ),
        patterns=(
            PatternHint("State pattern", ("state",),
                        "each state decides which operations are valid; no giant if/else", "Operations are only valid in certain situations"),
            PatternHint("Payment strategy", ("payment", "method"),
                        "new payment methods plug in without modifying the machine", "Card payments may be added later"),
        ),
    ),
)


class ProblemCatalog:
    def __init__(self, problems: list[Problem] | None = None):
        self._problems = {p.id: p for p in (problems or [PARKING_LOT, ELEVATOR, VENDING])}

    def list(self) -> list[Problem]:
        return list(self._problems.values())

    def get(self, problem_id: str) -> Problem:
        if problem_id not in self._problems:
            raise NotFound(f"unknown problem '{problem_id}'")
        return self._problems[problem_id]
