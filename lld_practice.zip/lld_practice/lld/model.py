"""Format-independent representation of a learner's design (what evaluators see)."""
from __future__ import annotations

import re
from dataclasses import dataclass, field

BUILTIN_TYPES = {
    "String", "Integer", "Long", "Double", "Float", "Boolean", "Object", "Number", "Void",
    "List", "Map", "Set", "Queue", "Deque", "Stack", "Array", "Optional", "Collection",
    "PriorityQueue", "HashMap", "ArrayList", "HashSet", "LinkedList", "TreeMap", "Iterator",
    "Date", "DateTime", "LocalDateTime", "LocalDate", "Instant", "Duration", "Timestamp",
    "Decimal", "BigDecimal", "UUID", "Lock", "Thread", "Exception", "Error", "Int", "Bool",
}
_IDENT = re.compile(r"[A-Za-z_]\w*")


@dataclass
class MethodSpec:
    name: str
    params: str = ""
    returns: str = ""


@dataclass
class ClassSpec:
    name: str
    kind: str = "class"  # class | abstract | interface | enum
    extends: list[str] = field(default_factory=list)
    implements: list[str] = field(default_factory=list)
    fields: list[tuple[str, str]] = field(default_factory=list)
    methods: list[MethodSpec] = field(default_factory=list)

    @property
    def parents(self) -> list[str]:
        return self.extends + self.implements

    @property
    def is_abstraction(self) -> bool:
        return self.kind in ("interface", "abstract")

    def type_references(self) -> set[str]:
        """Capitalised identifiers used in field types and method signatures."""
        texts = [t for _, t in self.fields] + [m.params + " " + m.returns for m in self.methods]
        refs = {i for t in texts for i in _IDENT.findall(t) if i[0].isupper()}
        refs.discard(self.name)
        return refs - BUILTIN_TYPES


@dataclass
class DesignModel:
    classes: dict[str, ClassSpec] = field(default_factory=dict)

    def implementers_of(self, name: str) -> list[ClassSpec]:
        return [c for c in self.classes.values() if name in c.parents]

    def dangling_references(self) -> set[str]:
        out: set[str] = set()
        for c in self.classes.values():
            out |= {r for r in c.type_references() if r not in self.classes}
            out |= {p for p in c.parents if p not in self.classes and p not in BUILTIN_TYPES}
        return out

    def related_names(self) -> set[str]:
        """Declared classes that participate in at least one relationship."""
        related: set[str] = set()
        for c in self.classes.values():
            for ref in set(c.parents) | c.type_references():
                if ref in self.classes and ref != c.name:
                    related |= {c.name, ref}
        return related
