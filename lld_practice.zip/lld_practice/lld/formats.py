"""Submission formats. Each format is a DesignParser; add a new one by registering it."""
from __future__ import annotations

import json
import re
from abc import ABC, abstractmethod

from .model import ClassSpec, DesignModel, MethodSpec


class DesignParseError(ValueError):
    def __init__(self, errors: list[str]):
        super().__init__("; ".join(errors))
        self.errors = errors


class DesignParser(ABC):
    format_id: str
    description: str
    template: str

    @abstractmethod
    def parse(self, content: str) -> DesignModel: ...


_DECL = re.compile(r"^(abstract\s+class|class|interface|enum)\s+([A-Za-z_]\w*)\s*(.*)$")
_METHOD = re.compile(r"^(\w+)\s*\(([^)]*)\)\s*(?::\s*(.+))?$")
_FIELD = re.compile(r"^(\w+)\s*:\s*(.+)$")
_HERITAGE = re.compile(r"\b(extends|implements)\b")


class DslParser(DesignParser):
    """Compact text DSL: unindented `class X extends Y implements Z`, indented members."""
    format_id = "dsl"
    description = "Text outline: declarations unindented, fields `name: Type`, methods `name(args): Return`."
    template = ("# Declarations are unindented; members are indented.\n"
                "interface Example\n  doThing(input: Input): Output\n"
                "class Impl implements Example\n  state: List<Item>\n  doThing(input: Input): Output\n")

    def parse(self, content: str) -> DesignModel:
        errors: list[str] = []
        classes: dict[str, ClassSpec] = {}
        current: ClassSpec | None = None
        for n, raw in enumerate(content.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if raw[0] not in " \t":
                current = self._declaration(n, line, classes, errors)
            elif current is None:
                errors.append(f"line {n}: member '{line}' appears before any class declaration")
            else:
                self._member(n, line, current, errors)
        if not classes and not errors:
            errors.append("no classes found")
        if errors:
            raise DesignParseError(errors)
        return DesignModel(classes)

    @staticmethod
    def _declaration(n, line, classes, errors):
        m = _DECL.match(line)
        if not m:
            errors.append(f"line {n}: expected 'class|abstract class|interface|enum Name', got '{line}'")
            return None
        kind, name, rest = m.group(1), m.group(2), m.group(3).strip()
        kind = "abstract" if kind.startswith("abstract") else kind
        spec = ClassSpec(name, kind)
        parts = _HERITAGE.split(rest)
        if parts[0].strip():
            errors.append(f"line {n}: unexpected text '{parts[0].strip()}' after name")
        for key, names in zip(parts[1::2], parts[2::2]):
            targets = [t.strip() for t in names.split(",") if t.strip()]
            (spec.extends if key == "extends" else spec.implements).extend(targets)
        if name in classes:
            errors.append(f"line {n}: '{name}' is declared twice")
            return None
        classes[name] = spec
        return spec

    @staticmethod
    def _member(n, line, spec, errors):
        line = line.lstrip("+-#~ ").strip()
        if spec.kind == "enum" and re.fullmatch(r"\w+", line):
            return  # enum constant
        if "(" in line:
            m = _METHOD.match(line)
            if not m:
                errors.append(f"line {n}: could not read method '{line}'")
                return
            spec.methods.append(MethodSpec(m.group(1), m.group(2).strip(), (m.group(3) or "").strip()))
            return
        m = _FIELD.match(line)
        if not m:
            errors.append(f"line {n}: could not read field '{line}' (use `name: Type`)")
            return
        spec.fields.append((m.group(1), m.group(2).strip()))


class JsonParser(DesignParser):
    """Machine-friendly format (e.g. produced by a diagram exporter)."""
    format_id = "json"
    description = 'JSON: {"classes":[{"name","kind","extends","implements","fields":[{"name","type"}],"methods":[{"name","params","returns"}]}]}'
    template = '{"classes": [{"name": "Example", "kind": "interface", "methods": [{"name": "doThing"}]}]}'

    def parse(self, content: str) -> DesignModel:
        try:
            data = json.loads(content)
            raw = data["classes"]
            classes: dict[str, ClassSpec] = {}
            for c in raw:
                spec = ClassSpec(c["name"], c.get("kind", "class"), list(c.get("extends", [])),
                                 list(c.get("implements", [])),
                                 [(f["name"], f.get("type", "")) for f in c.get("fields", [])],
                                 [MethodSpec(m["name"], m.get("params", ""), m.get("returns", ""))
                                  for m in c.get("methods", [])])
                if spec.kind not in ("class", "abstract", "interface", "enum"):
                    raise DesignParseError([f"unknown kind '{spec.kind}' for {spec.name}"])
                if spec.name in classes:
                    raise DesignParseError([f"'{spec.name}' is declared twice"])
                classes[spec.name] = spec
        except DesignParseError:
            raise
        except (json.JSONDecodeError, KeyError, TypeError, AttributeError) as e:
            raise DesignParseError([f"invalid JSON design: {e!r}"])
        if not classes:
            raise DesignParseError(["no classes found"])
        return DesignModel(classes)


class FormatRegistry:
    def __init__(self, parsers: list[DesignParser] | None = None):
        self._parsers: dict[str, DesignParser] = {}
        for p in parsers or []:
            self.register(p)

    def register(self, parser: DesignParser) -> None:
        self._parsers[parser.format_id] = parser

    def get(self, format_id: str) -> DesignParser:
        if format_id not in self._parsers:
            raise ValueError(f"unsupported submission format '{format_id}'")
        return self._parsers[format_id]

    def describe(self) -> list[dict]:
        return [{"id": p.format_id, "description": p.description, "template": p.template}
                for p in self._parsers.values()]
