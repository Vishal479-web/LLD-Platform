"""Composition root: the only place that knows which concrete classes are wired together."""
from __future__ import annotations

import os

from .evaluators import EvaluationPipeline, RuleBasedEvaluator
from .formats import DslParser, FormatRegistry, JsonParser
from .llm import AnthropicClient, LLMEvaluator
from .problems import ProblemCatalog
from .repository import SqliteAttemptRepository
from .service import PracticeService


def build_service(db_path: str | None = None) -> PracticeService:
    optional = []
    if os.environ.get("ANTHROPIC_API_KEY"):
        optional.append(LLMEvaluator(AnthropicClient()))
    pipeline = EvaluationPipeline(required=[RuleBasedEvaluator()], optional=optional)
    service = PracticeService(SqliteAttemptRepository(db_path or os.environ.get("LLD_DB", "lld_practice.db")),
                              ProblemCatalog(), FormatRegistry([DslParser(), JsonParser()]), pipeline)
    service.recover_stale()
    return service
